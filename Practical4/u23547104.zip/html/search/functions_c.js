var searchData=
[
  ['truck_0',['Truck',['../class_truck.html#a87e358bca8fe34e6299c6ff233afb08b',1,'Truck::Truck()'],['../class_truck.html#a219d1f79f9d09d9f0ab34bd65156e861',1,'Truck::Truck(const Truck *other)']]]
];
