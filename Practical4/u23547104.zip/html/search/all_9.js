var searchData=
[
  ['next_0',['next',['../class_b_f_s.html#a2153e4cb2b44704f4be35e63658e5f76',1,'BFS::next()'],['../class_d_f_s.html#aa50a2f678437054eadad34406dd28693',1,'DFS::next()'],['../class_iterator.html#ac639e96c519e2e78cff17bee372ad750',1,'Iterator::next()']]]
];
