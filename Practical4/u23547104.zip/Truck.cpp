#include "Truck.h"

Truck::Truck(){

}

Truck::Truck(const Truck* other) {

}