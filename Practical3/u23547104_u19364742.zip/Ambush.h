#ifndef AMBUSH_H
#define AMBUSH_H

#include "BattleStrategy.h"

class Ambush : public BattleStrategy {
        public:
                void engage();
                BattleStrategy* clone() const;
};

#endif
