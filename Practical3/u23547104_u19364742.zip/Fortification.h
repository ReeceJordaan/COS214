#ifndef FORTIFICATION_H
#define FORTIFICATION_H

#include "BattleStrategy.h"

class Fortification : public BattleStrategy {
	public:
                void engage();
                BattleStrategy* clone() const;
};

#endif