#include "SmartDeviceCommand.h"
#include <iostream>
using namespace std;

SmartDeviceCommand::SmartDeviceCommand(){}

SmartDeviceCommand::~SmartDeviceCommand(){}